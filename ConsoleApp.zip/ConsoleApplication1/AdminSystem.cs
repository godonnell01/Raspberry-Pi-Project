﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class AdminSystem
    {
        private String Username;
        private String Password;

        public void Admin(String Username, String Password)
        {
            Program Prog = new Program();
            bool Menu = true;

            SetUser(Username, Password);
            
            Console.WriteLine("\nYou are in the Admin system\n");

            while (Menu)
            {

                Console.WriteLine("------\n Menu\n------\n");
                Console.WriteLine("Display all users in the system - 1\n");
                Console.WriteLine("Display all admins in the system - 2\n");
                Console.WriteLine("Change username and password - 3\n");
                Console.WriteLine("Display user info - 4\n");
                Console.WriteLine("Add a user to the system - 5\n");
                Console.WriteLine("Remove a user from the system - 6\n");
              //  Console.WriteLine("Remove an admin - 6\n");
                Console.WriteLine("Make an existing user an admin - 7\n");
                Console.WriteLine("Log out - 8\n");

                int Input = Convert.ToInt32(Console.ReadLine());

                switch(Input)
                {
                    case 1:

                        Prog.DisplayUsers();
                        break;

                    case 2:

                        Prog.DisplayAdmins();
                        break;

                    case 3:

                        Console.WriteLine("\nEnter new username");
                        String NewUser = Console.ReadLine();

                        Console.WriteLine("\nEnter new password");
                        String NewPassword = Console.ReadLine();

                        Prog.UpdateAdmin(GetUsername(), GetPassword(), NewUser, NewPassword);
                        Console.WriteLine("\nUpdate successful");
                        break;

                    case 4:

                        Console.WriteLine("\nUsername:\t" + GetUsername());
                        Console.WriteLine("\nPassword:\t" + GetPassword() + "\n");
                        Console.WriteLine("\nPress Enter to return to menu\n");
                        Console.ReadLine();
                        break;

                    case 5:

                        Console.WriteLine("\nEnter username for new user");
                        String NewUsername = Console.ReadLine();

                        Console.WriteLine("\nEnter password for new user");
                        String NewUserPassword = Console.ReadLine();

                        Console.WriteLine("\nDo you want the new user " + NewUsername + " to be an admin? (y/n)");
                        char AdminAnswer = Console.ReadKey().KeyChar;
                        Console.ReadLine();

                        Console.WriteLine("\nPress Enter to add new user");
                        Console.ReadLine();

                        if (Prog.CheckUserInDB(NewUsername))
                        {
                            Console.WriteLine("\nFailed to add new user: User " + NewUsername + " alreadys exists within the database\n");
                        }

                        else
                        {
                            if (AdminAnswer.Equals('y'))
                            {
                                Prog.AddAdmin(NewUsername, NewUserPassword);
                            }

                            Prog.AddUser(NewUsername, NewUserPassword);
                            Console.WriteLine("\nUser " + NewUsername + " has been added\n\n");
                        }
                        
                        break;

                    case 6:

                        Console.WriteLine("\nEnter the username of the user to be removed");
                        String RemUsername = Console.ReadLine();

                        if(RemUsername.Equals(GetUsername()))
                        {
                            Console.WriteLine("\nAre you sure you want to remove yourself from the system? (y/n)");
                            char RemoveSelfAnswer = Console.ReadKey().KeyChar;
                            Console.ReadLine();

                            if (RemoveSelfAnswer.Equals('y'))
                            {
                                Console.WriteLine("\nEnter your admin password");
                                String AdminPassword = Console.ReadLine();
                                if (Prog.RemoveUser(AdminPassword, RemUsername))
                                {
                                    Console.WriteLine("\nYou has been removed from the system\n\n");
                                    Prog.LogOut();
                                }

                                else
                                {
                                    Console.WriteLine("\nUser removal failed: Incorrect Admin password entered\n\n");
                                }
                            }

                            else if (RemoveSelfAnswer.Equals('n'))
                            {
                                Console.WriteLine("\nUser removal cancelled\n");
                            }

                            else
                            {
                                Console.WriteLine("\nInvalid input: User removal cancelled\n");
                            }
                        }

                        else
                        {
                            if (Prog.CheckUserInDB(RemUsername))
                            {
                                Console.WriteLine("\nAre you sure you want to remove the user " + RemUsername + "? (y/n)");
                                char RemoveAnswer = Console.ReadKey().KeyChar;

                                Console.ReadLine();

                                if (RemoveAnswer.Equals('y'))
                                {
                                    Console.WriteLine("\nEnter your admin password");
                                    String AdminPassword = Console.ReadLine();
                                    if (Prog.RemoveUser(AdminPassword, RemUsername))
                                    {
                                        Console.WriteLine("\nUser " + RemUsername + " has been removed\n\n");
                                    }

                                    else
                                    {
                                        Console.WriteLine("\nUser removal failed: Incorrect Admin password entered\n\n");
                                    }
                                }

                                else if (RemoveAnswer.Equals('n'))
                                {
                                    Console.WriteLine("\nUser removal cancelled\n");
                                }

                                else
                                {
                                    Console.WriteLine("\nInvalid input: User removal cancelled\n");
                                }
                            }

                            else
                            {
                                Console.WriteLine("\nUser removal failed: User " + RemUsername + " was not found in the database\n\n");
                            }
                        }
                        
                        break;

                    

                    case 7:

                        Console.WriteLine("\nEnter the name of the user you would like to make an admin");
                        String User = Console.ReadLine();

                        Console.WriteLine("\nEnter the current password for user " + User);
                        String Pass = Console.ReadLine();

                        if(Prog.AddExistingAdmin(User, Pass))
                        {
                            Console.WriteLine("\nUser " + User + " is now an admin\n");
                            break;
                        }

                        else
                        {
                            Console.WriteLine("\nUser " + User + " is not an exising user in the system and therefore can not be made an admin");
                            break;
                        }
                        

                    case 8:

                        Menu = false;
                        Console.WriteLine("\n-------------\n Logging out\n-------------\n");
                        Prog.LogOut();
                        break;

                    default:

                        Console.WriteLine("\nInvalid input\n");
                        break;

                }

               
            }



        }

        public void SetUser(String Username, String Password)
        {
            this.Username = Username;
            this.Password = Password;
        }

        public String GetUsername()
        {
            return Username;
        }

        public String GetPassword()
        {
            return Password;
        }
    }
}
