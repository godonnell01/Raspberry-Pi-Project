﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Finisar.SQLite;

namespace ConsoleApplication1
{
    class Program
    {
        private SQLiteConnection Connection;
        private SQLiteCommand Command;
        private SQLiteDataReader Datareader;
        private String User;
        private String Password;

        UserSystem UserSys = new UserSystem();
        AdminSystem AdminSys = new AdminSystem();


        public void SetUser(String User)
        {
            this.User = User;
        }

        public void SetPassword(String Password)
        {
            this.Password = Password;
        }

        public String GetUser()
        {
            return User;
        }

        public String GetPassword()
        {
            return Password;
        }

        public void SetUpDatabase()
        {
            var Connect = @"Data Source=C:\C#\ConsoleApplication1\ConsoleLogin.db;New=True;Version=3;Compress=True;";
            Connection = new SQLiteConnection(Connect);


            Connection.Open();

            Command = Connection.CreateCommand();

            
            Command.CommandText = "CREATE TABLE users (Usernames varchar (20), UserPasswords varchar (100));";
            Command.ExecuteNonQuery();

            Command.CommandText = "CREATE TABLE admins (AdminNames varchar (20), AdminPasswords varchar (100));";
            Command.ExecuteNonQuery();

            Command.CommandText = "INSERT INTO users (Usernames, UserPasswords) VALUES ('Phil', '1234');";
            Command.ExecuteNonQuery();

            Command.CommandText = "INSERT INTO users (Usernames, UserPasswords) VALUES ('Mike', 'poi');";
            Command.ExecuteNonQuery();

            Command.CommandText = "INSERT INTO users (Usernames, UserPasswords) VALUES ('Bob', 'qwe');";
            Command.ExecuteNonQuery();

            Command.CommandText = "INSERT INTO admins (AdminNames, AdminPasswords) VALUES ('Phil', '1234');";
            Command.ExecuteNonQuery();


            Connection.Close();
            
        }

        public void ConnectToDatabase()
        {

            String User = GetUser();
            String Password = GetPassword();

            bool UserLogin = false;
            bool AdminLogin = false;


            var Connect = @"Data Source=C:\C#\ConsoleApplication1\ConsoleLogin.db;Version=3;Compress=True;";
            Connection =  new SQLiteConnection(Connect);


            Connection.Open();

            Command = Connection.CreateCommand();

/*
            Command.CommandText = "CREATE TABLE users (Usernames varchar (20), UserPasswords varchar (100));";
            Command.ExecuteNonQuery();

            Command.CommandText = "CREATE TABLE admins (AdminNames varchar (20), AdminPasswords varchar (100));";
            Command.ExecuteNonQuery();

            Command.CommandText = "INSERT INTO users (Usernames, UserPasswords) VALUES ('Phil', '1234');";
            Command.ExecuteNonQuery();

            Command.CommandText = "INSERT INTO users (Usernames, UserPasswords) VALUES ('Mike', 'poi');";
            Command.ExecuteNonQuery();

            Command.CommandText = "INSERT INTO users (Usernames, UserPasswords) VALUES ('Bob', 'qwe');";
            Command.ExecuteNonQuery();

            Command.CommandText = "INSERT INTO admins (AdminNames, AdminPasswords) VALUES ('Phil', '1234');";
            Command.ExecuteNonQuery();
*/

            Command.CommandText = "SELECT * FROM users WHERE Usernames = '" + User + "' AND UserPasswords = '" + Password + "';";
            Datareader = Command.ExecuteReader();

            if (Datareader.Read())
            {
                UserLogin = true;
                Datareader.Close();
            }

            else
            {
                Datareader.Close();
            }

            Command.CommandText = "SELECT * FROM admins WHERE AdminNames = '" + User + "' AND AdminPasswords = '" + Password + "';";
            Datareader = Command.ExecuteReader();

            if (Datareader.Read())
            {
                AdminLogin = true;
                Datareader.Close();
            }

            else
            {
                Datareader.Close();
            }

            
            if (UserLogin)
            {

                if (AdminLogin)
                {
                    AdminSys.Admin(User, Password);
                }

                else
                {
                    UserSys.User(User, Password);
                }
            }

            else
            {
                Console.WriteLine("\nLogin failed\n");
                Login LoginPage = new Login();

                User = null;
                Password = null;
                LoginPage.Log();

            }


            Console.ReadLine();

            Connection.Close();
        }

        public void DisplayAdmins()
        {
            var Connect = @"Data Source=C:\C#\ConsoleApplication1\ConsoleLogin.db;Version=3;Compress=True;"; 
            Connection = new SQLiteConnection(Connect);


            Connection.Open();

            Command = Connection.CreateCommand();

            Command.CommandText = "SELECT * FROM admins";
            Datareader = Command.ExecuteReader();

            Console.WriteLine("\nAdmins\n------");
            while (Datareader.Read())
            {

                string Output = Datareader[0].ToString();
                Console.WriteLine(Output);
            }
            Console.WriteLine("\nPress Enter to return to menu\n");
            Console.ReadLine();
            Connection.Close();
        }

        public void DisplayUsers()
        {
            var Connect = @"Data Source=C:\C#\ConsoleApplication1\ConsoleLogin.db;Version=3;Compress=True;";
            Connection = new SQLiteConnection(Connect);


            Connection.Open();

            Command = Connection.CreateCommand();

            Command.CommandText = "SELECT * FROM users";
            Datareader = Command.ExecuteReader();

            Console.WriteLine("\nUsers\n-----");
            while(Datareader.Read())
            {

                string Output = Datareader[0].ToString();
                Console.WriteLine(Output);
            }
            Console.WriteLine("\nPress Enter to return to menu\n");
            Console.ReadLine();
            Connection.Close();
        }

        public void LogOut()
        {
            Login LoginPage = new Login();

            User = null;
            Password = null;
            LoginPage.Log();
        }

        public bool CheckUserInDB(String User)
        {
            var Connect = @"Data Source=C:\C#\ConsoleApplication1\ConsoleLogin.db;Version=3;Compress=True;";
            Connection = new SQLiteConnection(Connect);

            Connection.Open();

            Command = Connection.CreateCommand();
            Command.CommandText = "SELECT * FROM users WHERE Usernames = '" + User + "';";
            Datareader = Command.ExecuteReader();

            if (Datareader.Read())
            {
                Connection.Close();
                return true; ;
            }

            Connection.Close();
            return false;
        }

        public void AddAdmin(String User, String Password)
        {
            var Connect = @"Data Source=C:\C#\ConsoleApplication1\ConsoleLogin.db;Version=3;Compress=True;";
            Connection = new SQLiteConnection(Connect);

            Connection.Open();

            Command = Connection.CreateCommand();

            Command.CommandText = "INSERT INTO admins (AdminNames, AdminPasswords) VALUES ('"+User+"', '"+Password+"');";
            Command.ExecuteNonQuery();

            Connection.Close();
        }

        public bool AddExistingAdmin(String User, String Password)
        {
            var Connect = @"Data Source=C:\C#\ConsoleApplication1\ConsoleLogin.db;Version=3;Compress=True;";
            Connection = new SQLiteConnection(Connect);

            Connection.Open();

            Command = Connection.CreateCommand();
            Command.CommandText = "SELECT * FROM users WHERE Usernames = '" + User + "' AND UserPasswords = '" + Password + "';";
            Datareader = Command.ExecuteReader();

            if (Datareader.Read())
            {
                Datareader.Close();
                Command.CommandText = "INSERT INTO admins (AdminNames, AdminPasswords) VALUES ('" + User + "', '" + Password + "');";
                Command.ExecuteNonQuery();
                Connection.Close();
                return true; 
            }

            else
            {
                Connection.Close();
                return false;
            }
           
        }

        public void AddUser(String User, String Password)
        {
            var Connect = @"Data Source=C:\C#\ConsoleApplication1\ConsoleLogin.db;Version=3;Compress=True;";
            Connection = new SQLiteConnection(Connect);

            Connection.Open();

            Command = Connection.CreateCommand();

            Command.CommandText = "INSERT INTO users (Usernames, UserPasswords) VALUES ('"+User+"', '"+Password+"');";
            Command.ExecuteNonQuery();

            Connection.Close();
        }

        public bool RemoveUser(String AdminPassword, String User)
        {
            var Connect = @"Data Source=C:\C#\ConsoleApplication1\ConsoleLogin.db;Version=3;Compress=True;";
            Connection = new SQLiteConnection(Connect);

            Connection.Open();

            Command = Connection.CreateCommand();
           
            Command.CommandText = "SELECT * FROM admins WHERE AdminPasswords = '" + AdminPassword + "';";
            Datareader = Command.ExecuteReader();

            if (Datareader.Read())
            {
                Datareader.Close();
                Command.CommandText = "DELETE FROM users WHERE Usernames = '" + User + "';";
                Command.ExecuteNonQuery();

                Command.CommandText = "SELECT * FROM admins WHERE AdminNames = '" + User + "';";
                Datareader = Command.ExecuteReader();

                if (Datareader.Read())
                {
                    Datareader.Close();
                    Command.CommandText = "DELETE FROM admins WHERE AdminNames = '" + User + "';";
                    Command.ExecuteNonQuery();
                }
                Connection.Close();



                return true;
            }

            return false;
        }

        public void UpdateAdmin(String OldUser, String OldPassword, String NewUser, String NewPassword)
        {
            var Connect = @"Data Source=C:\C#\ConsoleApplication1\ConsoleLogin.db;Version=3;Compress=True;";
            Connection = new SQLiteConnection(Connect);

            Connection.Open();

            Command = Connection.CreateCommand();

            Command.CommandText = "UPDATE admins SET AdminNames = '" + NewUser + "' WHERE AdminNames = '" + OldUser + "';";
            Command.ExecuteNonQuery();

            Command.CommandText = "UPDATE admins SET AdminPasswords = '" + NewPassword + "' WHERE AdminPasswords = '" + OldPassword + "';";
            Command.ExecuteNonQuery();

            Connection.Close();

            UpdateUser(OldUser, OldPassword, NewUser, NewPassword);
        }

        public void UpdateUser(String OldUser, String OldPassword, String NewUser, String NewPassword)
        {
            var Connect = @"Data Source=C:\C#\ConsoleApplication1\ConsoleLogin.db;Version=3;Compress=True;";
            Connection = new SQLiteConnection(Connect);

            Connection.Open();

            Command = Connection.CreateCommand();

            Command.CommandText = "UPDATE users SET Usernames = '"+NewUser+"' WHERE Usernames = '"+OldUser+"';";
            Command.ExecuteNonQuery();
           
            Command.CommandText = "UPDATE users SET UserPasswords = '"+NewPassword+"' WHERE UserPasswords = '"+OldPassword+"';";
            Command.ExecuteNonQuery();

            Connection.Close();

        }

        

    }

}
