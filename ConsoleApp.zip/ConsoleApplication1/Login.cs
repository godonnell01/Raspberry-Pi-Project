﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Login
    {
        

        static void Main(string[] args)
        {
            Program Prog = new Program();
            Prog.SetUpDatabase();

            Login LoginPage = new Login();
            LoginPage.Log();
        }

        public void Log()
        {
            Program Prog = new Program();
            Console.WriteLine("\n-------\n Login \n-------\n");

            Console.WriteLine("\nEnter your username");
            String User = Console.ReadLine();

            Console.WriteLine("\nEnter your password");
            String Password = Console.ReadLine();

            Console.WriteLine("\nPress Enter to login");
            Console.ReadLine();

            Prog.SetUser(User);
            Prog.SetPassword(Password);
            Prog.ConnectToDatabase();
            
            
        }



    }
}

