﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class UserSystem
    {
        private String Username;
        private String Password;

        public void User(String Username, String Password)
        {
            Program Prog = new Program();
            bool Menu = true;
            SetUser(Username, Password);

            Console.WriteLine("\nYou are in the User system\n");
            while(Menu)
            {
                
                Console.WriteLine("------\n Menu\n------\n");
                Console.WriteLine("Display all users in the system - 1\n");
                Console.WriteLine("Change username and password - 2\n");
                Console.WriteLine("Display user info - 3\n");
                Console.WriteLine("Log out - 4\n");

                int Input = Convert.ToInt32(Console.ReadLine());

                switch(Input)
                {
                    case 1:

                        Prog.DisplayUsers();
                        break;

                    case 2:

                        Console.WriteLine("\nEnter new username");
                        String NewUser = Console.ReadLine();

                        Console.WriteLine("\nEnter new password");
                        String NewPassword = Console.ReadLine();

                        Prog.UpdateUser(GetUsername(), GetPassword(), NewUser, NewPassword);
                        Console.WriteLine("\nUpdate successful");
                        break;

                    case 3:

                        Console.WriteLine("\nUsername:\t" + GetUsername());
                        Console.WriteLine("\nPassword:\t" + GetPassword() + "\n");
                        Console.WriteLine("\nPress Enter to return to menu\n");
                        Console.ReadLine();
            
                        break;

                    case 4:

                        Menu = false;
                        Console.WriteLine("\n-------------\n Logging out\n-------------\n");
                        Prog.LogOut();
                        break;

                    default:

                        Console.WriteLine("\nInvalid input\n");
                        break;

                }
        
            }
            
       }

        public void SetUser(String Username, String Password)
        {
            this.Username = Username;
            this.Password = Password;
        }

        public String GetUsername()
        {
            return Username;
        }

        public String GetPassword()
        {
            return Password;
        }

    }

}
